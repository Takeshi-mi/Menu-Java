/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package telaloginmtp;


import view.TelaLogin;
import view.FrmPrincipal;
public class TelaLoginMTP {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        FrmPrincipal principal = new FrmPrincipal();
        principal.setVisible(true);
        TelaLogin login = new TelaLogin();
        login.setVisible(true);
    }
    
}
