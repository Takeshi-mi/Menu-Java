
package model;

public class Cidade {
    public int id;
    public String nome, uf, cep;
    
   
        
}
