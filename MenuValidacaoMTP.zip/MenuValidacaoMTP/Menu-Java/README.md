# Menu-Java
Construção de um Menu feito com Java utilizando JFrame com algumas ferramentas inclusas como cadastro de Cidades, calculadora e bloco de notas.
