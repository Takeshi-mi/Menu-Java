
package calculadoratakeshi;
import view.FmrCalculadora;

public class CalculadoraTakeshi {
    public static void main(String[] args) {
        FrmCalculadora frame = new FrmCalculadora();
        frame.setVisible(true);
    }
}